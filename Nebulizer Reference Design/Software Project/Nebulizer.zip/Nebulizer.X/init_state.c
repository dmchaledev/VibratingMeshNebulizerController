//
// MICROCHIP SOFTWARE NOTICE AND DISCLAIMER:  You may use this software, and any derivatives created by any person
// or entity by or on your behalf, exclusively with Microchip's products.  Microchip and its licensors retain all
// ownership and intellectual property rights in the accompanying software and in all derivatives hereto.
//
// This software and any accompanying information is for suggestion only.  It does not modify Microchip's standard
// warranty for its products.  You agree that you are solely responsible for testing the software and determining
// its suitability.  Microchip has no obligation to modify, test, certify, or support the software.
//
// THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING,
// BUT NOT LIMITED TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE
// APPLY TO THIS SOFTWARE, ITS INTERACTION WITH MICROCHIP'S PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN
// ANY APPLICATION.
//
// IN NO EVENT, WILL MICROCHIP BE LIABLE, WHETHER IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF
// STATUTORY DUTY), STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, PUNITIVE,
// EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
// SOFTWARE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
// TO THE FULLEST EXTENT ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
// WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
//
// MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS.
//

#include "mcc_generated_files/mcc.h"
#include "nebulizer.h"


// Global RAM




void INIT_State(void)
{
    if (flags.bits.BoostDelay == 0)
    {
        //* Enable FVR
        FVR_Initialize();
        
        // Set up Comparator DACs
        DAC1_Initialize();              // Enable DAC1
        DAC1_SetOutput(BOOST_CMP);      // Sets Boost Voltage
        
        DAC2_Initialize();              // Enable DAC2
        DAC2_SetOutput(0x0a);           // Set for Max Current

        //* Set Freq to Sweep Base Value
        OUTPUT_FREQ(FREQ_BASE);
        
        //* Enable VSUPPLY
        POWER_ON;
        
        //* Enable BOOST
        BOOST_ON;
        
        //* Set Boost Delay
        setTimer(MS100);                // Delay for Boost Stage Startup
        flags.bits.BoostDelay = 1;      // Start Timer
    }
    else if (flags.bits.BoostReady)
    {
        //* Set Max Treatment Timer
        maxTreatmentTimer = MAX_OP;     // Set up Maximum Treatment Time 
        
        flags.bits.PeakDetect = 0;      // No Peak Detected
        maxVal = 0;
        maxFreq = FREQ_START;           // Lowest Valid Frequency
        localMax = 0;                   // Set to Lowest Possible
        localMin = 1023;                // Set to Highest Possible
        riseFilter = 0;                 // Clear Filters
        fallFilter = 0;                 // Clear Filters
        flags.bits.Falling = 1;         // Assume Value is Decreasing
        
        //* Enable Output
        OUTPUT_ON;
        
        //* Enter SWEEP State
        state = SWEEP;
        TP20_LAT = 1;
        ADC_Ref_FVR();                  // Set ADC Reference to FVR for Freq Sweep
    }
}

