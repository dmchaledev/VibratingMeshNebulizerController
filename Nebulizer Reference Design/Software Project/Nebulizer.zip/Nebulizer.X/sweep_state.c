//
// MICROCHIP SOFTWARE NOTICE AND DISCLAIMER:  You may use this software, and any derivatives created by any person
// or entity by or on your behalf, exclusively with Microchip's products.  Microchip and its licensors retain all
// ownership and intellectual property rights in the accompanying software and in all derivatives hereto.
//
// This software and any accompanying information is for suggestion only.  It does not modify Microchip's standard
// warranty for its products.  You agree that you are solely responsible for testing the software and determining
// its suitability.  Microchip has no obligation to modify, test, certify, or support the software.
//
// THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING,
// BUT NOT LIMITED TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE
// APPLY TO THIS SOFTWARE, ITS INTERACTION WITH MICROCHIP'S PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN
// ANY APPLICATION.
//
// IN NO EVENT, WILL MICROCHIP BE LIABLE, WHETHER IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF
// STATUTORY DUTY), STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, PUNITIVE,
// EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
// SOFTWARE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
// TO THE FULLEST EXTENT ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
// WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
//
// MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS.
//

#include "mcc_generated_files/mcc.h"
#include "nebulizer.h"


// Global RAM

uint16_t outCurrent;     // Output Current
uint16_t localMin;       // Local Minimum Output Current
uint16_t localMax;       // Local Maximum Output Current
uint16_t maxVal;         // Detected Peak Output Current
uint16_t localFreq;      // Frequency at Local Maximum
uint16_t maxFreq;        // Detected Peak Frequency
uint16_t newFreq;        // New Frequency to Write to NCO
uint8_t  riseFilter;     // Rising Trend Filter
uint8_t  fallFilter;     // Falling Trend Filter

// Function Prototypes

void SWEEP_State(void)
{
    if (NCO1INC > FREQ_TOP)         // Frequency Sweep Completed?
    {
        TP20_LAT = 0;
        if (flags.bits.PeakDetect)
        {
            //* Set Freq to Saved Value
            OUTPUT_FREQ(maxFreq);

            //* Enter RUN State
            state = RUN; 
        }
        else
        {
            //* Set Indication to Long Alternate Flash
            flags.bits.FlashRed = 1;
            flags.bits.FlashGrn = 1;
            setIndicate(LONGFLASH);
            
            //* Enter STOP State
            state = STOP;
        }
    }
    else                            // Frequency Sweeping
    {
        TP7_LAT = 0;
        //* Read Output Current
        if (NCO1INC > FREQ_START)
        {
            outCurrent = ADC_GetConversion(OPA2OUT);
            
            //* Trend == Falling?
            if (flags.bits.Falling)
            {
                TP20_LAT = 1;
                //* Current > Local Min Current?
                if (outCurrent > localMin)
                {
                    //* Current > Local Min + Offset?
                    if (outCurrent > (localMin + NOISELEVEL))
                    {
                        riseFilter++;
                        if (riseFilter > TREND)
                        {
                            //* Local Max = Current
                            localMax = outCurrent;
                            //* Local Freq = Freq
                            localFreq = NCO1INC;
                            //* Trend = Rising
                            flags.bits.Falling = 0;
                        }
                    }
                }
                else
                {
                    //* Local Min = Current
                    localMin = outCurrent;
                    
                    if (riseFilter)
                    {
                        riseFilter = 0;
                    }
                }
            }
            else
            {
                TP20_LAT = 0;
                //Current > Local Max Current?
                if (outCurrent > localMax)
                {
                    //* Local Max = Current
                    localMax = outCurrent;
                    //* Local Freq = Freq
                    localFreq = NCO1INC;
                    
                    if (fallFilter)
                    {
                        fallFilter = 0;
                    }
                }
                else
                {
                    //* Current < Local Max Current - Offset?
                    if (outCurrent < (localMax - NOISELEVEL))
                    {
                        fallFilter++;
                        if (fallFilter > TREND)
                        {
                            //* Local Min = Current
                            localMin = outCurrent;
                            //* Trend = Falling
                            flags.bits.Falling = 1;
                            //* Save Local Max and Freq
                            if ((maxVal < localMax) && (flags.bits.PeakDetect == 0))
                            {
                                maxVal = localMax;      // Save Value from Peak
                                maxFreq = localFreq;    // Save Frequency from Peak
                                
                                //* Set Peak Detected
                                flags.bits.PeakDetect = 1;
                                TP7_LAT = 1;
                            }

                        }
                    }
                }
            }
        }
        //* Increase Frequency by Step Size
        newFreq = (uint16_t)(NCO1INC + FREQ_STEP);
        OUTPUT_FREQ(newFreq);
    }
    
}
