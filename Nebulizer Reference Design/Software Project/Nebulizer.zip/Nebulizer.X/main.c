/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using MPLAB(c) Code Configurator

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  MPLAB(c) Code Configurator - v3.00
        Device            :  PIC16F1713
        Driver Version    :  2.00
    The generated drivers are tested against the following:
        Compiler          :  XC8 1.35
        MPLAB             :  MPLAB X 3.20
*/

/*
Copyright (c) 2013 - 2015 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 */

#include "mcc_generated_files/mcc.h"
#include "nebulizer.h"


// Global RAM

STATE state;                // App State Value 
FLAGWORD flags;             // Flag bits

uint8_t postScale;          // Post Scaler for Timebase

uint16_t maxTreatmentTimer; // Max Operating Timer

uint8_t flashTime;          // Counter for INDICATE Flash Timing


// Function Prototypes

void APP_Initialize(void);
void Maintain_Timers(void);


/*
                         Main application
 */
void main(void)
{
    // initialize the device
    SYSTEM_Initialize();
    
    APP_Initialize();

    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    //INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();

    while (1)
    {
        Maintain_Timers();
        
        switch (state)
        {
            case INIT:
                INIT_State();
                break;
                
            case SWEEP:
                SWEEP_State();
                break;
                
            case RUN:
                RUN_State();
                break;
                
            case STOP:
                STOP_State();
                break;
                
            case INDICATE:
                INDICATE_State();
                break;
                
            case SLEEP:
                SLEEP_State();
                break;
                
            default:
                state = STOP;
        
        }
    }
}

void APP_Initialize(void)
{

    flags.all = 0;              // Clear All Flag Bits
    OUTPUT_FREQ(FREQ_BASE);
    flags.bits.FlashTimer = 1;  // No Timer for Indication
    state = STOP;
    
}

    
void Maintain_Timers(void)
{
    NOP();
    
    // TMR0, 4MHz, 1:256 Prescaler - 16.384ms
    if (TMR0IF)     
    {
        TMR0IF = 0;                                 // Clear Interrupt Flag
        if (postScale)
        {
            postScale--;
        }
        if (postScale == 0)
        {
            postScale = 30;                         // Reload Post Scaler to Get to 500ms
            flags.bits.FlashToggle = ~flags.bits.FlashToggle;   // Toggle Red/Green LED
            if (flashTime)
            {
                flashTime--;
                if (flashTime == 0)
                {
                    flags.bits.FlashTimer = 1;          // Timer Expired
                }
            }
            if (maxTreatmentTimer)
            {
                maxTreatmentTimer--;                    // Count Timer Down
            }
        }
    }
    
    // TMR1, 4 MHz, 1:8 Prescaler - 2us
    if (TMR1IF)
    {
        TMR1_StopTimer();                   // TMR1 is one shot...
        if (flags.bits.BoostDelay)          // If waiting for boost stage...
        {
            flags.bits.BoostDelay = 0;
            flags.bits.BoostReady = 1;
            TMR1IF = 0;                     // Clear Timeout Indication
        }
        else if (flags.bits.ButtonPress)
        {
            flags.bits.ButtonPress = 0;
            flags.bits.Debounce = 1;
            TMR1IF = 0;                     // Clear Timeout
        }
    }
}


// Timer 1 used for shorter delays - Boost voltage delay time, button debounce
// This routine 
void setTimer(uint16_t value)
{
    TMR1_StopTimer();
    TMR1IF = 0;
    TMR1_WriteTimer(value);
    TMR1_StartTimer();
}

void setIndicate(uint8_t value)
{
    TMR0 = 0;                       // Restart Timer
    flags.bits.FlashToggle = 0;     // Always Start on Same LED
    flags.bits.FlashTimer = 0;      // Timer is Not Expired
    flashTime = value;              // Set Flash Time
}

/**
 End of File
*/