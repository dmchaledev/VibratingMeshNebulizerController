//
// MICROCHIP SOFTWARE NOTICE AND DISCLAIMER:  You may use this software, and any derivatives created by any person
// or entity by or on your behalf, exclusively with Microchip's products.  Microchip and its licensors retain all
// ownership and intellectual property rights in the accompanying software and in all derivatives hereto.
//
// This software and any accompanying information is for suggestion only.  It does not modify Microchip's standard
// warranty for its products.  You agree that you are solely responsible for testing the software and determining
// its suitability.  Microchip has no obligation to modify, test, certify, or support the software.
//
// THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING,
// BUT NOT LIMITED TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE
// APPLY TO THIS SOFTWARE, ITS INTERACTION WITH MICROCHIP'S PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN
// ANY APPLICATION.
//
// IN NO EVENT, WILL MICROCHIP BE LIABLE, WHETHER IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF
// STATUTORY DUTY), STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, PUNITIVE,
// EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
// SOFTWARE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
// TO THE FULLEST EXTENT ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
// WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
//
// MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS.
//

#include "mcc_generated_files/mcc.h"
#include "nebulizer.h"


// Global RAM
adc_result_t batteryVoltage;

// Function Prototypes

void RUN_State(void)
{
    if (SWITCH_PORT == 0)           //* Is Button Pressed?
    {
        //* Flag Button Press
        flags.bits.ButtonPress = 1;
        flags.bits.Debounce = 0;
        
        //* Set 20ms Timer
        setTimer(MS20);
    }
    
    //* Read Battery Voltage
    ADC_Ref_VDD();
    batteryVoltage = ADC_GetConversion(channel_FVRBuffer1);
    
    //* Update Boost Duty Cycle by Battery Voltage
        // TODO
    
        GRN_LED_ON();
//    if (batteryVoltage < LOW_BATTERY_M_HYST)           //* Is Battery < 3.5v?
//    {
//        //* Red LED Off
//        RED_LED_OFF();
//        
//        //* Green LED On
//        GRN_LED_ON();
//    }
//    else if (batteryVoltage > LOW_BATTERY_P_HYST)      
//    {
//        //* Red LED On
//        RED_LED_ON();
//        
//        //* Green LED Off
//        GRN_LED_OFF();
//    }
//    
//    if(batteryVoltage > SHUTDOWN_M_HYST)            //* Is Battery < 2.9v?
//    {
//        //* Set Indication to Long Red Flash
//        flags.bits.FlashRed = 1;
//        flags.bits.FlashGrn = 0;
//        setIndicate(LONGFLASH);
//
//        //* State = STOP
//        state = STOP;
//    }
//    else 
        if (maxTreatmentTimer == 0)      //* Max Treatment Timer Expired?
    {
        //* Set Indication to Long Green Flash
            flags.bits.FlashRed = 0;
            flags.bits.FlashGrn = 1;
            setIndicate(LONGFLASH);
            
        //* State = STOP
        state = STOP;
    }
    else if(flags.bits.Debounce)       //* Button Press Timer Expired?
    {
        if (SWITCH_PORT)       //* Is Button Released
        {
            flags.bits.Debounce = 0;
            
            //* Set Indication to None
            flags.bits.FlashRed = 0;
            flags.bits.FlashGrn = 0;
            flags.bits.FlashTimer = 1;      // No Time Delay

            //* State = STOP
            state = STOP;
        }
    }
        
}
