/* 
 * File:   nebulizer.h
 * Author: C13607
 *
 * Created on March 28, 2016, 9:05 AM
 */

#ifndef NEBULIZER_H
#define	NEBULIZER_H

#ifdef	__cplusplus
extern "C" {
#endif

#pragma warning disable 520     // function is never called
#pragma warning disable 751     // arithmetic overflow in constant expression
#pragma warning disable 752     // conversion to shorter data type
    
/*
 * Project Defines
 */
    
// State Machine
typedef enum 
{
    INIT,
    SWEEP,
    RUN,
    STOP,
    INDICATE,
    SLEEP
}STATE;

typedef union
{
    uint16_t all;
    struct
    {
        unsigned BoostDelay:1;        // Boost Delay Active
        unsigned BoostReady:1;        // Boost Stage Ready
        unsigned PeakDetect:1;        // Sweep Function Detected a Local Maximum Peak
        unsigned Falling:1;           // Sweep Current Decreasing
        unsigned ButtonPress:1;       // Button Press Detected
        unsigned Debounce:1;          // Button Debounce Timer
        unsigned FlashToggle:1;       // Decides if LED Flash is Red or Green
        unsigned FlashRed:1;          // Set if Red LED Should Flash
        unsigned FlashGrn:1;          // Set if Green LED Should Flash
        unsigned FlashTimer:1;        // Set When Flash Timer Expires
        unsigned bitA:1;        //
        unsigned bitB:1;        //
        unsigned bitC:1;        //
        unsigned bitD:1;        //
        unsigned bitE:1;        //
        unsigned bitF:1;        //
    }bits;
}FLAGWORD;

extern STATE state;
extern FLAGWORD flags;

extern uint16_t maxTreatmentTimer;


// INIT State   
    
#define POWER       (BST_ENB_LAT)       // Pin to Enable Power Circuit
#define POWER_ON    POWER = 0
#define POWER_OFF   POWER = 1

#define BOOST_ON    CLC1GLS1 = 8    // LC1D2G2T = 1
#define BOOST_OFF   CLC1GLS1 = 0    // LC1D2G2T = 0
#define BOOST_VOLTAGE   10

#define OUTPUT_ON   NCO1CONbits.N1EN = 1
#define OUTPUT_OFF  NCO1CONbits.N1EN = 0
#define OUTPUT_FREQ(x) {                                    \
                        NCO1INCH = (uint8_t)((x)>>8);       \
                        NCO1INCL = (uint8_t)((x)&0xff);     \
                       }

#define TIMER1MS(x) (65536L - ((x)*500L))    // Do Not Change!!! Used to Calculate Timer 1 Values

#define MS100   TIMER1MS(100)    

    

// SWEEP State
    
#define HI_FREQ 150000          // High Value for Frequency Scan
#define LO_FREQ 100000          // Low Value for Frequency Scan
#define BS_FREQ 90000           // Base Frequency
#define NOISELEVEL 90           // ADC Counts Necessary to Switch Between Increasing/!Increasing
#define TREND 130                // Number of Samples for Rising/Falling Before Change of Direction is Accepted
#define FREQ_STEP   1

#define FREQ_OUT    (LATA7)
#define FREQ_PIN    (RA7)

extern uint16_t outCurrent;     // Output Current
extern uint16_t localMin;       // Local Minimum Output Current
extern uint16_t localMax;       // Local Maximum Output Current
extern uint16_t maxVal;         // Detected Peak Output Current
extern uint16_t localFreq;      // Frequency at Local Maximum
extern uint16_t maxFreq;        // Detected Peak Frequency
extern uint16_t newFreq;        // New Frequency to Write to NCO
extern uint8_t  riseFilter;     // Rising Trend Filter
extern uint8_t  fallFilter;     // Falling Trend Filter

// RUN State    

#define LOW_BATTERY 3.5         // Low Battery Detect Voltage
#define HYST 0.05               // Hysteresis in Low Battery Reading
#define SHUTDOWN 2.9            // Low Battery Shutdown
    
#define ADC_Ref_VDD()   ADCON1bits.ADPREF = 0
#define ADC_Ref_FVR()   ADCON1bits.ADPREF = 3

#define MINUTE          120                 // 1 Minute
#define MAX_OP          (10 * MINUTE)       // Maximum Operation Time

#define MS20    TIMER1MS(20)

#define RED_LED_ON()    LED_RED_SetHigh()
#define RED_LED_OFF()   LED_RED_SetLow()

#define GRN_LED_ON()    LED_GRN_SetHigh()
#define GRN_LED_OFF()   LED_GRN_SetLow()


    
extern uint16_t batteryVoltage; // Battery Voltage Reading


// INDICATE State
    
#define LONGFLASH 10
#define SHORTFLASH 6

void setIndicate(uint8_t);

// STOP State

#define FVR_OFF()   FVRCONbits.FVREN = 0
#define DAC1_OFF()  DAC1CON0bits.DAC1EN = 0
#define DAC2_OFF()  DAC2CON0bits.DAC2EN = 0

    
//-------------------------------------------------------------------
// These #defines are for calculations based on definitions above and should not require any changes
//    
//-------------------------------------------------------------------

#define NCORATE 7.62939453      // Set by Clocking into NCO - Number of Hz per step
#define _XTAL_FREQ  16000000    // Operating Frequency

#define FREQ_BASE   (uint16_t)(BS_FREQ/NCORATE)
#define FREQ_START  (uint16_t)(LO_FREQ/NCORATE)
#define FREQ_TOP    (uint16_t)(HI_FREQ/NCORATE)

#define ADC_VREF  2.048
#define LOW_BATTERY_P_HYST ((int)((ADC_VREF * 1023)/(LOW_BATTERY + HYST)))
#define LOW_BATTERY_M_HYST ((int)((ADC_VREF * 1023)/(LOW_BATTERY - HYST)))

#define SHUTDOWN_P_HYST ((int)((ADC_VREF * 1023)/(SHUTDOWN + HYST)))
#define SHUTDOWN_M_HYST ((int)((ADC_VREF * 1023)/(SHUTDOWN - HYST)))

#define CMP1_VREF 2.048
#define CMP1_STEP ((CMP1_VREF)/256)
#define BV_DIVIDER ((15.0)/(221.0 + 15.0))            // R5, R8
#define BOOST_CMP  ((uint8_t)((BOOST_VOLTAGE * BV_DIVIDER)/CMP1_STEP))

    
    
    
//-------------------------------------------------------------------
// Function Prototypes
//    
//-------------------------------------------------------------------

// State Functions
    
extern void INIT_State(void);
extern void SWEEP_State(void);
extern void RUN_State(void);
extern void STOP_State(void);
extern void INDICATE_State(void);
extern void SLEEP_State(void);

// Timer Function
void setTimer(uint16_t value);


#ifdef	__cplusplus
}
#endif

#endif	/* NEBULIZER_H */

