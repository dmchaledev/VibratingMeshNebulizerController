/**
  Generated Pin Manager File

  Company:
    Microchip Technology Inc.

  File Name:
    pin_manager.c

  Summary:
    This is the Pin Manager file generated using MPLAB(c) Code Configurator

  Description:
    This header file provides implementations for pin APIs for all pins selected in the GUI.
    Generation Information :
        Product Revision  :  MPLAB(c) Code Configurator - v3.00
        Device            :  PIC16F1713
        Driver Version    :  1.02
    The generated drivers are tested against the following:
        Compiler          :  XC8 1.35
        MPLAB             :  MPLAB X 3.20

    Copyright (c) 2013 - 2015 released Microchip Technology Inc.  All rights reserved.

    Microchip licenses to you the right to use, modify, copy and distribute
    Software only when embedded on a Microchip microcontroller or digital signal
    controller that is integrated into your product or third party product
    (pursuant to the sublicense terms in the accompanying license agreement).

    You should refer to the license agreement accompanying this Software for
    additional information regarding your rights and obligations.

    SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
    EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
    MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
    IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
    CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
    OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
    INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
    CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
    SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
    (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

*/

#include <xc.h>
#include "pin_manager.h"
#include <stdbool.h>

void PIN_MANAGER_Initialize(void)
{
    LATB = 0x0;
    WPUE = 0x8;
    LATA = 0x08;
    LATC = 0x2;
    WPUA = 0x80;
    WPUB = 0x0;
    WPUC = 0x41;
    ANSELA = 0x37;
    ANSELB = 0x1E;
    ANSELC = 0x40;
    TRISE = 0x8;
    TRISB = 0xDC;
    TRISC = 0xA5;
    TRISA = 0x31;

    OPTION_REGbits.nWPUEN = 0x0;

    // interrupts-on-change are globally disabled
    INTCONbits.IOCIE = 0;
    bool state = GIE;
    GIE = 0;
    PPSLOCK = 0x55;
    PPSLOCK = 0xAA;
    PPSLOCKbits.PPSLOCKED = 0x00; // unlock PPS

    CLCIN1PPSbits.CLCIN1PPS = 0x0001;   //RA1->CLC1:CLCIN1;
    RXPPSbits.RXPPS = 0x0017;   //RC7->EUSART:RX;
    CLCIN0PPSbits.CLCIN0PPS = 0x0000;   //RA0->CLC1:CLCIN0;
    CLCIN2PPSbits.CLCIN2PPS = 0x000E;   //RB6->CLC1:CLCIN2;
    CLCIN3PPSbits.CLCIN3PPS = 0x000F;   //RB7->CLC1:CLCIN3;
    RA7PPSbits.RA7PPS = 0x0003;   //RA7->NCO1:NCO1OUT;
    T0CKIPPSbits.T0CKIPPS = 0x0004;   //RA4->TMR0:T0CKI;
    RA6PPSbits.RA6PPS = 0x0004;   //RA6->CLC1:CLC1OUT;
    RC6PPSbits.RC6PPS = 0x0014;   //RC6->EUSART:TX;

    PPSLOCK = 0x55;
    PPSLOCK = 0xAA;
    PPSLOCKbits.PPSLOCKED = 0x01; // lock PPS
    GIE = state;
}


void PIN_MANAGER_IOC(void)
{    
}

/**
 End of File
*/