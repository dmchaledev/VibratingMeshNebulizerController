/**
  @Generated Pin Manager Header File

  @Company:
    Microchip Technology Inc.

  @File Name:
    pin_manager.h

  @Summary:
    This is the Pin Manager file generated using MPLAB(c) Code Configurator

  @Description:
    This header file provides implementations for pin APIs for all pins selected in the GUI.
    Generation Information :
        Product Revision  :  MPLAB(c) Code Configurator - v3.00
        Device            :  PIC16F1713
        Version           :  1.01
    The generated drivers are tested against the following:
        Compiler          :  XC8 1.35
        MPLAB             :  MPLAB X 3.20

    Copyright (c) 2013 - 2015 released Microchip Technology Inc.  All rights reserved.

    Microchip licenses to you the right to use, modify, copy and distribute
    Software only when embedded on a Microchip microcontroller or digital signal
    controller that is integrated into your product or third party product
    (pursuant to the sublicense terms in the accompanying license agreement).

    You should refer to the license agreement accompanying this Software for
    additional information regarding your rights and obligations.

    SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
    EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
    MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
    IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
    CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
    OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
    INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
    CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
    SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
    (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

*/


#ifndef PIN_MANAGER_H
#define PIN_MANAGER_H

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0



// get/set BST_ENB aliases
#define BST_ENB_TRIS               TRISA3
#define BST_ENB_LAT                LATA3
#define BST_ENB_PORT               RA3
#define BST_ENB_WPU                WPUA3
#define BST_ENB_ANS                ANSA3
#define BST_ENB_SetHigh()    do { LATA3 = 1; } while(0)
#define BST_ENB_SetLow()   do { LATA3 = 0; } while(0)
#define BST_ENB_Toggle()   do { LATA3 = ~LATA3; } while(0)
#define BST_ENB_GetValue()         RA3
#define BST_ENB_SetDigitalInput()    do { TRISA3 = 1; } while(0)
#define BST_ENB_SetDigitalOutput()   do { TRISA3 = 0; } while(0)

#define BST_ENB_SetPullup()    do { WPUA3 = 1; } while(0)
#define BST_ENB_ResetPullup()   do { WPUA3 = 0; } while(0)
#define BST_ENB_SetAnalogMode()   do { ANSA3 = 1; } while(0)
#define BST_ENB_SetDigitalMode()   do { ANSA3 = 0; } while(0)


// get/set LED_RED aliases
#define LED_RED_TRIS               TRISB0
#define LED_RED_LAT                LATB0
#define LED_RED_PORT               RB0
#define LED_RED_WPU                WPUB0
#define LED_RED_ANS                ANSB0
#define LED_RED_SetHigh()    do { LATB0 = 1; } while(0)
#define LED_RED_SetLow()   do { LATB0 = 0; } while(0)
#define LED_RED_Toggle()   do { LATB0 = ~LATB0; } while(0)
#define LED_RED_GetValue()         RB0
#define LED_RED_SetDigitalInput()    do { TRISB0 = 1; } while(0)
#define LED_RED_SetDigitalOutput()   do { TRISB0 = 0; } while(0)

#define LED_RED_SetPullup()    do { WPUB0 = 1; } while(0)
#define LED_RED_ResetPullup()   do { WPUB0 = 0; } while(0)
#define LED_RED_SetAnalogMode()   do { ANSB0 = 1; } while(0)
#define LED_RED_SetDigitalMode()   do { ANSB0 = 0; } while(0)


// get/set LED_GRN aliases
#define LED_GRN_TRIS               TRISB5
#define LED_GRN_LAT                LATB5
#define LED_GRN_PORT               RB5
#define LED_GRN_WPU                WPUB5
#define LED_GRN_ANS                ANSB5
#define LED_GRN_SetHigh()    do { LATB5 = 1; } while(0)
#define LED_GRN_SetLow()   do { LATB5 = 0; } while(0)
#define LED_GRN_Toggle()   do { LATB5 = ~LATB5; } while(0)
#define LED_GRN_GetValue()         RB5
#define LED_GRN_SetDigitalInput()    do { TRISB5 = 1; } while(0)
#define LED_GRN_SetDigitalOutput()   do { TRISB5 = 0; } while(0)

#define LED_GRN_SetPullup()    do { WPUB5 = 1; } while(0)
#define LED_GRN_ResetPullup()   do { WPUB5 = 0; } while(0)
#define LED_GRN_SetAnalogMode()   do { ANSB5 = 1; } while(0)
#define LED_GRN_SetDigitalMode()   do { ANSB5 = 0; } while(0)


// get/set SWITCH aliases
#define SWITCH_TRIS               TRISC0
#define SWITCH_LAT                LATC0
#define SWITCH_PORT               RC0
#define SWITCH_WPU                WPUC0
#define SWITCH_SetHigh()    do { LATC0 = 1; } while(0)
#define SWITCH_SetLow()   do { LATC0 = 0; } while(0)
#define SWITCH_Toggle()   do { LATC0 = ~LATC0; } while(0)
#define SWITCH_GetValue()         RC0
#define SWITCH_SetDigitalInput()    do { TRISC0 = 1; } while(0)
#define SWITCH_SetDigitalOutput()   do { TRISC0 = 0; } while(0)

#define SWITCH_SetPullup()    do { WPUC0 = 1; } while(0)
#define SWITCH_ResetPullup()   do { WPUC0 = 0; } while(0)


// get/set USB_RST aliases
#define USB_RST_TRIS               TRISC1
#define USB_RST_LAT                LATC1
#define USB_RST_PORT               RC1
#define USB_RST_WPU                WPUC1
#define USB_RST_SetHigh()    do { LATC1 = 1; } while(0)
#define USB_RST_SetLow()   do { LATC1 = 0; } while(0)
#define USB_RST_Toggle()   do { LATC1 = ~LATC1; } while(0)
#define USB_RST_GetValue()         RC1
#define USB_RST_SetDigitalInput()    do { TRISC1 = 1; } while(0)
#define USB_RST_SetDigitalOutput()   do { TRISC1 = 0; } while(0)

#define USB_RST_SetPullup()    do { WPUC1 = 1; } while(0)
#define USB_RST_ResetPullup()   do { WPUC1 = 0; } while(0)


// get/set USB_CFG aliases
#define USB_CFG_TRIS               TRISC2
#define USB_CFG_LAT                LATC2
#define USB_CFG_PORT               RC2
#define USB_CFG_WPU                WPUC2
#define USB_CFG_ANS                ANSC2
#define USB_CFG_SetHigh()    do { LATC2 = 1; } while(0)
#define USB_CFG_SetLow()   do { LATC2 = 0; } while(0)
#define USB_CFG_Toggle()   do { LATC2 = ~LATC2; } while(0)
#define USB_CFG_GetValue()         RC2
#define USB_CFG_SetDigitalInput()    do { TRISC2 = 1; } while(0)
#define USB_CFG_SetDigitalOutput()   do { TRISC2 = 0; } while(0)

#define USB_CFG_SetPullup()    do { WPUC2 = 1; } while(0)
#define USB_CFG_ResetPullup()   do { WPUC2 = 0; } while(0)
#define USB_CFG_SetAnalogMode()   do { ANSC2 = 1; } while(0)
#define USB_CFG_SetDigitalMode()   do { ANSC2 = 0; } while(0)


// get/set TP20 aliases
#define TP20_TRIS               TRISC3
#define TP20_LAT                LATC3
#define TP20_PORT               RC3
#define TP20_WPU                WPUC3
#define TP20_ANS                ANSC3
#define TP20_SetHigh()    do { LATC3 = 1; } while(0)
#define TP20_SetLow()   do { LATC3 = 0; } while(0)
#define TP20_Toggle()   do { LATC3 = ~LATC3; } while(0)
#define TP20_GetValue()         RC3
#define TP20_SetDigitalInput()    do { TRISC3 = 1; } while(0)
#define TP20_SetDigitalOutput()   do { TRISC3 = 0; } while(0)

#define TP20_SetPullup()    do { WPUC3 = 1; } while(0)
#define TP20_ResetPullup()   do { WPUC3 = 0; } while(0)
#define TP20_SetAnalogMode()   do { ANSC3 = 1; } while(0)
#define TP20_SetDigitalMode()   do { ANSC3 = 0; } while(0)


// get/set TP7 aliases
#define TP7_TRIS               TRISC4
#define TP7_LAT                LATC4
#define TP7_PORT               RC4
#define TP7_WPU                WPUC4
#define TP7_ANS                ANSC4
#define TP7_SetHigh()    do { LATC4 = 1; } while(0)
#define TP7_SetLow()   do { LATC4 = 0; } while(0)
#define TP7_Toggle()   do { LATC4 = ~LATC4; } while(0)
#define TP7_GetValue()         RC4
#define TP7_SetDigitalInput()    do { TRISC4 = 1; } while(0)
#define TP7_SetDigitalOutput()   do { TRISC4 = 0; } while(0)

#define TP7_SetPullup()    do { WPUC4 = 1; } while(0)
#define TP7_ResetPullup()   do { WPUC4 = 0; } while(0)
#define TP7_SetAnalogMode()   do { ANSC4 = 1; } while(0)
#define TP7_SetDigitalMode()   do { ANSC4 = 0; } while(0)


// get/set USB_SSPND aliases
#define USB_SSPND_TRIS               TRISC5
#define USB_SSPND_LAT                LATC5
#define USB_SSPND_PORT               RC5
#define USB_SSPND_WPU                WPUC5
#define USB_SSPND_ANS                ANSC5
#define USB_SSPND_SetHigh()    do { LATC5 = 1; } while(0)
#define USB_SSPND_SetLow()   do { LATC5 = 0; } while(0)
#define USB_SSPND_Toggle()   do { LATC5 = ~LATC5; } while(0)
#define USB_SSPND_GetValue()         RC5
#define USB_SSPND_SetDigitalInput()    do { TRISC5 = 1; } while(0)
#define USB_SSPND_SetDigitalOutput()   do { TRISC5 = 0; } while(0)

#define USB_SSPND_SetPullup()    do { WPUC5 = 1; } while(0)
#define USB_SSPND_ResetPullup()   do { WPUC5 = 0; } while(0)
#define USB_SSPND_SetAnalogMode()   do { ANSC5 = 1; } while(0)
#define USB_SSPND_SetDigitalMode()   do { ANSC5 = 0; } while(0)


// get/set USB_SSPND aliases
#define USB_SSPND_TRIS               TRISC5
#define USB_SSPND_LAT                LATC5
#define USB_SSPND_PORT               RC5
#define USB_SSPND_WPU                WPUC5
#define USB_SSPND_ANS                ANSC5
#define USB_SSPND_SetHigh()    do { LATC5 = 1; } while(0)
#define USB_SSPND_SetLow()   do { LATC5 = 0; } while(0)
#define USB_SSPND_Toggle()   do { LATC5 = ~LATC5; } while(0)
#define USB_SSPND_GetValue()         RC5
#define USB_SSPND_SetDigitalInput()    do { TRISC5 = 1; } while(0)
#define USB_SSPND_SetDigitalOutput()   do { TRISC5 = 0; } while(0)

#define USB_SSPND_SetPullup()    do { WPUC5 = 1; } while(0)
#define USB_SSPND_ResetPullup()   do { WPUC5 = 0; } while(0)
#define USB_SSPND_SetAnalogMode()   do { ANSC5 = 1; } while(0)
#define USB_SSPND_SetDigitalMode()   do { ANSC5 = 0; } while(0)


// get/set USB_SSPND aliases
#define USB_SSPND_TRIS               TRISC5
#define USB_SSPND_LAT                LATC5
#define USB_SSPND_PORT               RC5
#define USB_SSPND_WPU                WPUC5
#define USB_SSPND_ANS                ANSC5
#define USB_SSPND_SetHigh()    do { LATC5 = 1; } while(0)
#define USB_SSPND_SetLow()   do { LATC5 = 0; } while(0)
#define USB_SSPND_Toggle()   do { LATC5 = ~LATC5; } while(0)
#define USB_SSPND_GetValue()         RC5
#define USB_SSPND_SetDigitalInput()    do { TRISC5 = 1; } while(0)
#define USB_SSPND_SetDigitalOutput()   do { TRISC5 = 0; } while(0)

#define USB_SSPND_SetPullup()    do { WPUC5 = 1; } while(0)
#define USB_SSPND_ResetPullup()   do { WPUC5 = 0; } while(0)
#define USB_SSPND_SetAnalogMode()   do { ANSC5 = 1; } while(0)
#define USB_SSPND_SetDigitalMode()   do { ANSC5 = 0; } while(0)



/**
 * @Param
    none
 * @Returns
    none
 * @Description
    GPIO and peripheral I/O initialization
 * @Example
    PIN_MANAGER_Initialize();
 */
void PIN_MANAGER_Initialize (void);

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handling routine
 * @Example
    PIN_MANAGER_IOC();
 */
void PIN_MANAGER_IOC(void);

#endif // PIN_MANAGER_H
/**
 End of File
*/