//
// MICROCHIP SOFTWARE NOTICE AND DISCLAIMER:  You may use this software, and any derivatives created by any person
// or entity by or on your behalf, exclusively with Microchip's products.  Microchip and its licensors retain all
// ownership and intellectual property rights in the accompanying software and in all derivatives hereto.
//
// This software and any accompanying information is for suggestion only.  It does not modify Microchip's standard
// warranty for its products.  You agree that you are solely responsible for testing the software and determining
// its suitability.  Microchip has no obligation to modify, test, certify, or support the software.
//
// THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING,
// BUT NOT LIMITED TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE
// APPLY TO THIS SOFTWARE, ITS INTERACTION WITH MICROCHIP'S PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN
// ANY APPLICATION.
//
// IN NO EVENT, WILL MICROCHIP BE LIABLE, WHETHER IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF
// STATUTORY DUTY), STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, PUNITIVE,
// EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
// SOFTWARE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
// TO THE FULLEST EXTENT ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
// WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
//
// MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS.
//

#include "mcc_generated_files/mcc.h"
#include "nebulizer.h"


// Global RAM


// Function Prototypes

void SLEEP_State(void)
{
    if(SWITCH_PORT)    //* Is Button Released?
    {
        //* Set Chip to Wake Up on Button Press
        IOCCF = 0;
        IOCCNbits.IOCCN0 = 1;
        INTCONbits.IOCIF = 0;
        INTCONbits.IOCIE = 1;
        
        //* Enter Sleep Mode
#ifdef __DEBUG
        while (INTCONbits.IOCIF == 0)
        { }
#else
        SLEEP();
#endif
        
        INTCONbits.IOCIE = 0;   // Disable Interrupt On Change
        
        if(SWITCH_PORT == 0)    //* Is Button Pressed?
        {
            while (SWITCH_PORT == 0)        // Wait for Button Release
            {
                __delay_ms(20);     //* Delay 20ms
            }
            
            FVR_Initialize();
            
            ADC_Ref_VDD();          // Set ADC Reference to VDD
            
            if (ADC_GetConversion(channel_FVRBuffer1) > SHUTDOWN_P_HYST)      //* Is Battery < 2.9v?
            {
                //* Set Indication to Short Red Flash
                flags.bits.FlashRed = 1;
                flags.bits.FlashGrn = 0;
                setIndicate(SHORTFLASH);
                
                //* State = INDICATE
                state = INDICATE;
            }
            else
            {
                //* State = INIT
                state = INIT;
            }
        }
    }
    
}
